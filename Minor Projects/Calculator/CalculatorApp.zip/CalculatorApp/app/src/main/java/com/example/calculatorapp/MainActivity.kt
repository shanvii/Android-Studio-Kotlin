package com.example.calculatorapp

//import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    var isNewOp = true
    var oldNumber = ""
    var op = "+"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun numberEvent(view: View) {
        if (isNewOp)
            editText.setText("")
        isNewOp = false


        var buclick:String = editText.text.toString()
        var buselect = view as Button
        when (buselect.id){
            Button1.id -> {buclick += "1"}
            Button2.id -> {buclick += "2"}
            Button3.id -> {buclick += "3"}
            Button4.id -> {buclick += "4"}
            Button5.id -> {buclick += "5"}
            Button6.id -> {buclick += "6"}
            Button7.id -> {buclick += "7"}
            Button8.id -> {buclick += "8"}
            Button9.id -> {buclick += "9"}
            Button0.id -> {buclick += "0"}
            Button_dot.id -> {buclick += "."}
        }
        editText.setText(buclick)
    }

    fun operatorEvent(view: View) {
        isNewOp = true
        oldNumber = editText.text.toString()
        var buselect:Button = view as Button
        when (buselect.id){
            Button_mul.id -> {op = "x"}
            Button_sub.id -> {op = "-"}
            Button_div.id -> {op = "/"}
            Button_add.id -> {op = "+"}

        }
    }

    fun equalEvent(view: View) {
        var newNumber:String = editText.text.toString()
        var result = 0.0
        when(op){
            "+" -> {result = oldNumber.toDouble() + newNumber.toDouble()}
            "-" -> {result = oldNumber.toDouble() - newNumber.toDouble()}
            "x" -> {result = oldNumber.toDouble() * newNumber.toDouble()}
            "/" -> {result = oldNumber.toDouble() / newNumber.toDouble()}
        }
        editText.setText(result.toString())
    }

    fun acEvent(view: View) {
        editText.setText("0")
        isNewOp = true
    }

    fun perEvent(view: View) {
        var no:Double = editText.text.toString().toDouble()/100
        editText.setText(no.toString())
        isNewOp = true
    }

    fun backEvent(view: View) {
        var bck:String= editText.text.toString()
        if (bck.length >0){
            bck = bck.substring(0,bck.length -1)
            editText.setText((bck))
        }
        isNewOp = true

    }
}