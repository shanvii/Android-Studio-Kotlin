package com.example.demologin_signin

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME,null,DATABASE_VERSION) {
    override fun onCreate(db: SQLiteDatabase) {
        val query = ("CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                NAME_COl + " TEXT," +
                EMAIL_COL + " TEXT" +
                PASSWORD_COL + "TEXT" +
                REPASSWORD_COL + "TEXT" + ")")
        db.execSQL(query)
    }

    override fun onUpgrade(db: SQLiteDatabase, p1: Int, p2: Int) {
        db.execSQL("drop Table if exists " + TABLE_NAME)
        onCreate(db)
    }

    fun insertuserdata(
        name: String,
        email: String,
        password: String,
        confirm_password: String
    ): Boolean {
        val db: SQLiteDatabase = writableDatabase
        val values: ContentValues = ContentValues()
        values.put("name", name)
        values.put("email", email)
        values.put("password", password)
        values.put("confirm_password", confirm_password)
        val result: Long = db.insert("user", null, values)

        if (result == -1L) {
            db.close()
            return false
        } else {
            db.close()
            return true
        }

    }
@SuppressLint("Recycle")
fun checkUser(email: String):Boolean{
    val bt = writableDatabase
    val cursor = bt.rawQuery("Select email from BCA where email =?", arrayOf(email),null)
    if (cursor.count<=0){
        cursor.close()
        return false
    }
    cursor.close()
    return true
}

fun userPresent(email:String ,password: String):Boolean{
    val db = writableDatabase
//    var columns:String = TABLE_NAME
//    var selection :String = EMAIL_COL + "=?"+"AND"+ PASSWORD_COL + "=?"
//    var selectionargs:String = {"email","password"}
//    val query = "Select * from"+ TABLE_NAME "where "+ EMAIL_COL = $email and password = $password"
    val cursor = db.rawQuery(
        "Select email , password from BCA where email = ? AND password= ? ", arrayOf(email , password),
        null
    )
    if (cursor.count<=0){
cursor.close()
        return false
    }
    cursor.close()
    return true
}
    companion object{
        // here we have defined variables for our database

        // below is variable for database name
        private val DATABASE_NAME = "ProjectDB"

        // below is the variable for database version
        private val DATABASE_VERSION = 1

        // below is the variable for table name
        val TABLE_NAME = "BCA"

        // below is the variable for id column
        val ID_COL = "id"

        // below is the variable for name column
        val NAME_COl = "name"

        // below is the variable for age column
        val EMAIL_COL = "email"

        val PASSWORD_COL = "password"

        val REPASSWORD_COL = "confirm_password"
    }
}