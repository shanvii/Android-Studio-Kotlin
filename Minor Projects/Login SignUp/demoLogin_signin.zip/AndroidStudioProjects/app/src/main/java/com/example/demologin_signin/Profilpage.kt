package com.example.demologin_signin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Profilpage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profilpage)
        supportActionBar?.hide()
val e1 = findViewById<Button>(R.id.bout)
        e1.setOnClickListener(){
            intent = Intent(this , HomePage::class.java)
            startActivity(intent)
        }
    }
}