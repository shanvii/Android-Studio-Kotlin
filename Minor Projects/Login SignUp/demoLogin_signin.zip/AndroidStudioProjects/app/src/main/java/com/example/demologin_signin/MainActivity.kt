package com.example.demologin_signin

import android.content.AsyncQueryHandler
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var handler: DatabaseHelper
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.hide()
        handler = DatabaseHelper(this)
        var b1 = findViewById<EditText>(R.id.retUsername)
        var b2 = findViewById<EditText>(R.id.retEmail)
        var b3 = findViewById<EditText>(R.id.retPassword)
        var b4 = findViewById<EditText>(R.id.reteditPassword)
        var a6 = findViewById<Button>(R.id.bregister)
        var a2 = findViewById<EditText>(R.id.edUsername)
        var a3 = findViewById<EditText>(R.id.edPassword)
        var a1 = findViewById<Button>(R.id.blogin)

a1.setOnClickListener(){
    if (a2.text.trim().isEmpty() || a3.text.trim().isEmpty()){
    Toast.makeText(this, "Input required",Toast.LENGTH_LONG).show()
    }else{
     var resk:Boolean= handler.userPresent(a2.text.toString(), a3.text.toString())
        if(resk == true){
            intent = Intent(this , Profilpage::class.java)
            startActivity(intent)
        }else{
            Toast.makeText(this, "Invalid credentials",Toast.LENGTH_LONG).show()
        }

    }


    }

    var a4 = findViewById<TextView>(R.id.tvRegister)
    a4.setOnClickListener(){
        intent = Intent(this , RegisterActivity::class.java)
        startActivity(intent)
    }
}
}


