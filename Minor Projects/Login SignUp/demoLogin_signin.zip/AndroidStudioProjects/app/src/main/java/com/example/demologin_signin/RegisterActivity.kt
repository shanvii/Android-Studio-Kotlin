package com.example.demologin_signin

import android.content.AsyncQueryHandler
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class RegisterActivity : AppCompatActivity() {
    lateinit var handler: DatabaseHelper
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        supportActionBar?.hide()
        handler = DatabaseHelper(this)
        var b1 = findViewById<EditText>(R.id.retUsername)
        var b2 = findViewById<EditText>(R.id.retEmail)
        var b3 = findViewById<EditText>(R.id.retPassword)
        var b4 = findViewById<EditText>(R.id.reteditPassword)
        var a6 = findViewById<Button>(R.id.bregister)
        var a2 = findViewById<EditText>(R.id.edUsername)
        var a3 = findViewById<EditText>(R.id.edPassword)

        a6.setOnClickListener() {

            if (b1.text.trim().isEmpty()||b2.text.trim().isEmpty()||b3.text.trim().isEmpty()||b4.text.trim().isEmpty()) {
                Toast.makeText(this, "Input required", Toast.LENGTH_LONG).show()
            } else {
                if (b3.getText().toString().equals(b4.getText().toString())) {
                    var usercheck: Boolean =
                        handler.checkUser(a2.text.toString())
                    if (usercheck == false) {
                        var insertcheck: Boolean = handler.insertuserdata(
                            b1.text.toString(),
                            b2.text.toString(),
                            b3.text.toString(),
                            b4.text.toString()
                        )
                        if (insertcheck == true) {

                            Toast.makeText(this, "Registration Successful", Toast.LENGTH_SHORT).show()
                            intent = Intent(this , Profilpage::class.java)
                            startActivity(intent)
                        } else {
                            Toast.makeText(this, "Registration failed ", Toast.LENGTH_SHORT).show()
                        }

                    } else {
                        Toast.makeText(
                            this,
                            "User already exist \n Please Login",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    Toast.makeText(this, "Password does not match", Toast.LENGTH_SHORT).show()
                }
            }
        }

        var a5 = findViewById<TextView>(R.id.tvLogin)
        a5.setOnClickListener() {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}
